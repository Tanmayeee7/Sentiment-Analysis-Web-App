import streamlit as st
from transformers import AutoModelForSequenceClassification, AutoTokenizer
import torch
import time  # For simulating processing time

# Define the Sentiment Analyzer class
class TransformerSentimentAnalyzer:
    def __init__(self, model_name="distilbert-base-uncased-finetuned-sst-2-english"):
        """Initialize the sentiment analyzer with a specified model."""
        self.device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
        self.tokenizer = AutoTokenizer.from_pretrained(model_name)
        self.model = AutoModelForSequenceClassification.from_pretrained(model_name).to(self.device)

    def analyze_sentiment(self, text):
        """Analyze the sentiment of a given text."""
        # Tokenize input text and send it to the model
        inputs = self.tokenizer(text, return_tensors="pt", truncation=True, padding=True).to(self.device)
        outputs = self.model(**inputs)

        # Get the predicted label
        label_id = torch.argmax(outputs.logits).item()
        labels = self.model.config.id2label
        sentiment = labels[label_id]

        return sentiment

# Streamlit App
def main():
    # App configuration
    st.set_page_config(
        page_title="Sentiment Analysis App",
        layout="wide",
    )

    st.title("Sentiment Analysis with Transformers")
    st.write("Analyze the sentiment of your text using a pre-trained model from Hugging Face.")

    # Initialize the analyzer
    analyzer = TransformerSentimentAnalyzer()

    # Text input
    user_input = st.text_area("Enter text for sentiment analysis:", height=150)

    if st.button("Analyze Sentiment"):
        if user_input.strip():
            with st.spinner("Analyzing..."):
                # Simulate a delay for better user experience
                time.sleep(2)

                try:
                    sentiment = analyzer.analyze_sentiment(user_input)
                    st.success(f"Sentiment: {sentiment}")
                except Exception as e:
                    st.error(f"Error during analysis: {e}")
        else:
            st.warning("Please enter some text.")

if __name__ == "__main__":
    main()
